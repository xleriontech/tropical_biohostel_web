import React, { useState } from "react";

interface SearchBarProps {
  onClose: () => void;
  onSearch: (destination: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ onClose, onSearch }) => {
  const [destination, setDestination] = useState("");
  const [dates, setDates] = useState({ checkIn: "", checkOut: "" });
  const [guests, setGuests] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (destination.trim()) {
      onSearch(destination.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-white">
      <div className="mx-auto flex max-w-4xl flex-col gap-6 p-6 lg:p-8">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-slate-900">¿A dónde te gustaría ir?</h2>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700">Destino</label>
              <input
                type="text"
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                placeholder="Ej: Barcelona, España"
                className="mt-1 w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200"
                required
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700">Check-in</label>
              <input
                type="date"
                value={dates.checkIn}
                onChange={(e) => setDates({ ...dates, checkIn: e.target.value })}
                className="mt-1 w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200"
              />
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700">Check-out</label>
              <input
                type="date"
                value={dates.checkOut}
                onChange={(e) => setDates({ ...dates, checkOut: e.target.value })}
                className="mt-1 w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200"
              />
            </div>
          </div>

          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-sm font-medium text-slate-700">Huéspedes</label>
              <select
                value={guests}
                onChange={(e) => setGuests(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200 bg-white"
              >
                <option value="">Seleccionar</option>
                <option value="1">1 adulto</option>
                <option value="2">2 adultos</option>
                <option value="3">3 adultos</option>
                <option value="4">4 adultos</option>
                <option value="5+">5+ adultos</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full rounded-lg bg-rose-500 py-4 text-center font-medium text-white shadow-sm hover:bg-rose-600"
          >
            Buscar propiedades
          </button>
        </form>
      </div>
    </div>
  );
};
