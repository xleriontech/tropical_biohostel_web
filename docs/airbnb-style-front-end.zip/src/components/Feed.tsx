import React, { useState, useMemo } from "react";
import { Property, properties } from "../data/mockData";
import { PropertyCard } from "./PropertyCard";
import { Sidebar } from "./Sidebar";

interface FeedProps {
  onPropertyClick: (property: Property) => void;
}

export const Feed: React.FC<FeedProps> = ({ onPropertyClick }) => {
  const [activeCategory, setActiveCategory] = useState("all");
  const [activePriceRange, setActivePriceRange] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredProperties = useMemo(() => {
    return properties.filter((property) => {
      if (activeCategory !== "all" && property.type.toLowerCase() !== activeCategory) {
        return false;
      }

      if (activePriceRange) {
        const range = activePriceRange;
        if (range === "Económico" && property.price > 100) return false;
        if (range === "Medio" && (property.price < 100 || property.price > 200)) return false;
        if (range === "Lujo" && property.price < 200) return false;
      }

      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = property.title.toLowerCase().includes(query);
        const matchesLocation = property.location.toLowerCase().includes(query);
        if (!matchesTitle && !matchesLocation) return false;
      }

      return true;
    });
  }, [activeCategory, activePriceRange, searchQuery]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
      <div className="flex gap-8">
        <Sidebar
          activeCategory={activeCategory}
          activePriceRange={activePriceRange}
          onCategoryChange={setActiveCategory}
          onPriceRangeChange={setActivePriceRange}
        />

        <div className="flex-1">
          <div className="mb-6">
            <div className="relative">
              <svg
                className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                />
              </svg>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar propiedades..."
                className="w-full rounded-lg border border-slate-300 bg-white pl-12 pr-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200"
              />
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <button
                onClick={() => setActiveCategory("all")}
                className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full transition ${
                  activeCategory === "all"
                    ? "bg-rose-500 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span>🏠</span>
                Todas
              </button>
              <button
                onClick={() => setActiveCategory("house")}
                className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full transition ${
                  activeCategory === "house"
                    ? "bg-rose-500 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span>🏡</span>
                Casas
              </button>
              <button
                onClick={() => setActiveCategory("apartment")}
                className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full transition ${
                  activeCategory === "apartment"
                    ? "bg-rose-500 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <span>🏢</span>
                Apartamentos
              </button>
            </div>
          </div>

          {filteredProperties.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredProperties.map((property) => (
                <PropertyCard
                  key={property.id}
                  property={property}
                  onPropertyClick={onPropertyClick}
                />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="rounded-full bg-slate-100 p-4">
                <svg className="h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <h3 className="mt-4 text-lg font-medium text-slate-900">No se encontraron resultados</h3>
              <p className="mt-1 text-sm text-slate-500">Intenta cambiar los filtros de búsqueda.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
