import React, { useState } from "react";
import { Property } from "../data/mockData";

interface PropertyDetailsProps {
  property: Property | null;
  onClose: () => void;
  onFavoriteToggle: (property: Property) => void;
}

export const PropertyDetails: React.FC<PropertyDetailsProps> = ({
  property,
  onClose,
  onFavoriteToggle,
}) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [guests, setGuests] = useState(2);

  if (!property) return null;

  const handleFavoriteToggle = () => {
    const updatedProperty = { ...property, isFavorite: !property.isFavorite };
    onFavoriteToggle(updatedProperty as Property);
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const nights = 3;
  const totalPrice = property.price * nights;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24" onClick={handleBackdropClick}>
      <div className="pointer-events-none absolute inset-0 bg-black/40" />

      <div className="pointer-events-auto relative w-full max-w-5xl mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-600 transition hover:bg-white hover:text-slate-900"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="grid lg:grid-cols-[1fr_400px]">
          {/* Main content */}
          <div className="p-6 lg:p-8">
            {/* Images */}
            <div className="mb-6">
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-200">
                <img
                  src={property.images[currentImageIndex]}
                  alt={property.title}
                  className="h-full w-full object-cover"
                />
                {property.images.length > 1 && (
                  <>
                    <button
                      onClick={() => setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-700 transition hover:bg-white"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </button>
                    <button
                      onClick={() => setCurrentImageIndex((prev) => (prev + 1) % property.images.length)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-700 transition hover:bg-white"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                    <div className="absolute bottom-3 right-3 bg-white/80 backdrop-blur-sm rounded-lg px-3 py-1.5 text-xs font-medium text-slate-700">
                      {currentImageIndex + 1} / {property.images.length}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* Title and rating */}
            <div className="mb-4">
              <div className="flex items-start gap-2">
                <h1 className="text-2xl font-semibold text-slate-900">{property.title}</h1>
                {property.isFavorite && (
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-rose-500 text-xs">
                    <svg className="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M2 10.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM6 10.333v5.43a2 2 0 01-.563 1.78l-2.77 5.336a2 2 0 01-1.669 1.046v2.237a2 2 0 01-1.772-1.864L7.54 11.77a1.5 1.5 0 01-.143-.781l-1.523-3.345a2 2 0 011.732-1.196h3.188a2 2 0 011.732 1.196l1.523 3.345a1.5 1.5 0 01.143.781 2 2 0 01-1.772 1.864v2.237a2 2 0 01-1.669-1.046L12 15.763V10.333z" />
                    </svg>
                  </span>
                )}
              </div>
              <p className="mt-1 text-slate-600">{property.location}</p>
              <div className="mt-2 flex items-center gap-1.5">
                <svg className="h-5 w-5 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span className="font-semibold text-slate-900">{property.rating}</span>
                <span className="text-slate-500">·</span>
                <span className="text-slate-500">{property.reviews} valoraciones</span>
              </div>
            </div>

            {/* Host card */}
            <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-xl mb-6">
              <img
                src={property.host.avatar}
                alt={property.host.name}
                className="h-14 w-14 rounded-full object-cover ring-2 ring-slate-200"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-slate-900">{property.host.name}</span>
                  {property.host.isSuperhost && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-xs font-medium text-rose-600">
                      <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M10 12a2 2 0 100-4 2 2 0 000 4zm0 0v-3m8 15H4v-2.5h16v2.5z" />
                      </svg>
                      Superhost
                    </span>
                  )}
                </div>
                <p className="text-sm text-slate-500">Anfitrión verificado</p>
              </div>
              <button className="rounded-lg border border-slate-200 px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-100">
                Contactar
              </button>
            </div>

            {/* Details */}
            <div className="grid gap-6 sm:grid-cols-2 mb-6">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
                  <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">{property.beds}</p>
                  <p className="text-xs text-slate-500">Camas</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
                  <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">{property.baths}</p>
                  <p className="text-xs text-slate-500">Baños</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
                  <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M13 10V7a1 1 0 00-1-1h-4a1 1 0 00-1 1v2m0 0a1 1 0 001-1h4a1 1 0 001 1m-5 4a1 1 0 00-1-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 01-1 1h-2m-3 4a1 1 0 00-1 1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 00-1 1m-6 0h6" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">{property.guests}</p>
                  <p className="text-xs text-slate-500">Huéspedes</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100">
                  <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-900">Wifi</p>
                  <p className="text-xs text-slate-500">Incluido</p>
                </div>
              </div>
            </div>

            {/* Amenities */}
            <div className="mb-6">
              <h3 className="mb-3 text-lg font-semibold text-slate-900">Amenidades</h3>
              <div className="grid gap-2 sm:grid-cols-2">
                {property.amenities.map((amenity) => (
                  <div key={amenity} className="flex items-center gap-2">
                    <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span className="text-sm text-slate-700">{amenity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="mb-3 text-lg font-semibold text-slate-900">Descripción</h3>
              <p className="text-slate-600">{property.description}</p>
            </div>
          </div>

          {/* Sidebar with booking */}
          <div className="border-t lg:border-t-0 lg:border-l border-slate-200 p-6 lg:p-8">
            <div className="sticky top-24">
              <div className="mb-4 flex items-baseline gap-1">
                <span className="text-2xl font-semibold text-slate-900">€{property.price}</span>
                <span className="text-sm text-slate-500">/ noche</span>
              </div>

              {property.originalPrice && (
                <div className="mb-4">
                  <span className="text-sm text-slate-500 line-through">€{property.originalPrice}</span>
                  <span className="ml-2 text-xs font-medium text-green-600">
                    -{((1 - property.price / property.originalPrice) * 100).toFixed(0)}% descuento
                  </span>
                </div>
              )}

              <div className="mb-6 rounded-xl bg-slate-50 p-4">
                <div className="flex items-baseline gap-1">
                  <span className="text-xl font-semibold text-slate-900">€{totalPrice}</span>
                  <span className="text-sm text-slate-500">por {nights} noches</span>
                </div>
                <p className="mt-1 text-xs text-slate-500">Impuestos y tasas incluidos</p>
              </div>

              {/* Guests selector */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-900">Huéspedes</label>
                <div className="mt-2 flex items-center gap-3 rounded-lg border border-slate-300 px-4 py-3">
                  <button
                    onClick={() => setGuests(Math.max(1, guests - 1))}
                    className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-100"
                  >
                    <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                    </svg>
                  </button>
                  <span className="text-sm font-medium text-slate-900">{guests}</span>
                  <button
                    onClick={() => setGuests(Math.min(property.guests, guests + 1))}
                    className="flex h-8 w-8 items-center justify-center rounded-full hover:bg-slate-100"
                  >
                    <svg className="h-5 w-5 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </button>
                </div>
              </div>

              {/* Reserve button */}
              <button className="w-full rounded-lg bg-rose-500 py-4 text-center font-semibold text-white shadow-sm hover:bg-rose-600">
                Reservar ahora
              </button>
              <p className="mt-2 text-center text-xs text-slate-500">Sin tarifas ocultas · Cancelación gratuita</p>

              {/* Favorite button */}
              <button
                onClick={handleFavoriteToggle}
                className="mt-4 w-full flex items-center justify-center gap-2 rounded-lg border border-slate-200 py-3 text-sm font-medium text-slate-700 hover:bg-slate-50"
              >
                {property.isFavorite ? (
                  <svg className="h-5 w-5 text-rose-500" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M2 10.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM6 10.333v5.43a2 2 0 01-.563 1.78l-2.77 5.336a2 2 0 01-1.669 1.046v2.237a2 2 0 01-1.772-1.864L7.54 11.77a1.5 1.5 0 01-.143-.781l-1.523-3.345a2 2 0 011.732-1.196h3.188a2 2 0 011.732 1.196l1.523 3.345a1.5 1.5 0 01.143.781 2 2 0 01-1.772 1.864v2.237a2 2 0 01-1.669-1.046L12 15.763V10.333z" />
                  </svg>
                ) : (
                  <svg className="h-5 w-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                )}
                {property.isFavorite ? "Guardado" : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
