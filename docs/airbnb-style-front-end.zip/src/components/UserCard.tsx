import React from "react";
import { User } from "../data/mockData";

interface UserCardProps {
  user: User;
  onUserClick: (user: User) => void;
}

export const UserCard: React.FC<UserCardProps> = ({ user, onUserClick }) => {
  return (
    <div
      className="group cursor-pointer rounded-xl border border-slate-200 bg-white p-5 transition hover:shadow-lg hover:border-slate-300"
      onClick={() => onUserClick(user)}
    >
      <div className="flex items-start gap-4">
        <div className="relative">
          <img
            src={user.avatar}
            alt={user.name}
            className="h-14 w-14 rounded-full object-cover ring-2 ring-slate-200"
          />
          {user.isSuperhost && (
            <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-xs font-bold text-white">
              S
            </span>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="truncate text-base font-semibold text-slate-900">{user.name}</h3>
          <p className="truncate text-sm text-slate-500">{user.location}</p>
          {user.isSuperhost && (
            <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-xs font-medium text-rose-600">
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4zm0 0v-3m8 15H4v-2.5h16v2.5z" />
              </svg>
              Superhost
            </span>
          )}
        </div>
      </div>

      <p className="mt-3 line-clamp-2 text-sm text-slate-600">{user.about}</p>

      <div className="mt-4 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="flex -space-x-1.5">
            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-slate-200 text-xs font-medium text-slate-600">
              {user.stats.guests}
            </div>
          </div>
          <span className="text-xs text-slate-500">invitados</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex -space-x-1.5">
            <div className="flex h-6 w-6 items-center justify-center rounded-full bg-rose-100 text-xs font-medium text-rose-600">
              {user.stats.hosted}
            </div>
          </div>
          <span className="text-xs text-slate-500">anfitciones</span>
        </div>
        <div className="flex items-center gap-1">
          <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
          <span className="text-xs font-medium text-slate-700">{user.responseRate}%</span>
        </div>
      </div>

      <div className="mt-4 flex items-center gap-4 text-xs font-medium text-slate-500">
        <span className="flex items-center gap-1">
          <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
          {user.joinedDate}
        </span>
        <span>{user.totalListings} propiedades</span>
      </div>
    </div>
  );
};
