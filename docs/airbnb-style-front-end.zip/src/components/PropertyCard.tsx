import React, { useState } from "react";
import { Property } from "../data/mockData";

interface PropertyCardProps {
  property: Property;
  onPropertyClick: (property: Property) => void;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, onPropertyClick }) => {
  const [showAllImages, setShowAllImages] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleImageClick = () => {
    if (property.images.length > 1) {
      setShowAllImages(true);
    }
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % property.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
  };

  return (
    <div
      className="relative group cursor-pointer"
      onClick={() => onPropertyClick(property)}
    >
      <div className="aspect-square w-full overflow-hidden rounded-xl bg-slate-200">
        {showAllImages ? (
          <div className="relative aspect-square w-full overflow-hidden bg-slate-200">
            <img
              src={property.images[currentImageIndex]}
              alt={property.title}
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowAllImages(false);
              }}
              className="absolute left-2 top-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-600 transition hover:bg-white"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            {property.images.length > 1 && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    prevImage();
                  }}
                  className="absolute left-2 top-1/2 z-10 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-600 transition hover:bg-white"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    nextImage();
                  }}
                  className="absolute right-2 top-1/2 z-10 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-600 transition hover:bg-white"
                >
                  <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </>
            )}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/30 to-transparent p-3">
              <div className="flex items-center justify-between">
                <div className="flex -space-x-2">
                  {property.images.slice(0, 3).map((img, i) => (
                    <img
                      key={i}
                      src={img}
                      alt=""
                      className="h-10 w-10 rounded-full border-2 border-white object-cover"
                    />
                  ))}
                </div>
                <span className="text-xs text-white/80">{property.images.length} fotos</span>
              </div>
            </div>
          </div>
        ) : (
          <img
            src={property.image}
            alt={property.title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            onClick={handleImageClick}
          />
        )}
      </div>

      <div className="mt-2">
        <div className="flex items-center gap-1.5">
          <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
          <span className="text-sm font-medium text-slate-900">{property.rating}</span>
          <span className="text-sm text-slate-500">·</span>
          <span className="text-sm text-slate-500">{property.reviews} valoraciones</span>
        </div>

        <h3 className="mt-1 truncate text-base font-semibold text-slate-900">
          {property.title}
        </h3>

        <p className="mt-1 truncate text-sm text-slate-600">{property.location}</p>

        <div className="mt-2 flex items-center gap-2">
          {property.host.isSuperhost && (
            <span className="inline-flex items-center gap-1 rounded-full bg-rose-50 px-2 py-0.5 text-xs font-medium text-rose-600">
              <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4zm0 0v-3m8 15H4v-2.5h16v2.5z" />
              </svg>
              Superhost
            </span>
          )}
        </div>

        <div className="mt-2 flex items-end gap-2">
          <span className="text-lg font-semibold text-slate-900">
            €{property.price}
          </span>
          <span className="text-sm text-slate-500"> / noche</span>
          {property.originalPrice && (
            <span className="ml-auto text-sm text-slate-500 line-through">
              €{property.originalPrice}
            </span>
          )}
        </div>
      </div>

      {property.isFavorite && (
        <div className="absolute right-2 top-2 rounded-full bg-white p-1 shadow-lg">
          <svg className="h-5 w-5 text-rose-500" fill="currentColor" viewBox="0 0 20 20">
            <path d="M2 10.5a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM6 10.333v5.43a2 2 0 01-.563 1.78l-2.77 5.336a2 2 0 01-1.669 1.046v2.237a2 2 0 01-1.772-1.864L7.54 11.77a1.5 1.5 0 01-.143-.781l-1.523-3.345a2 2 0 011.732-1.196h3.188a2 2 0 011.732 1.196l1.523 3.345a1.5 1.5 0 01.143.781 2 2 0 01-1.772 1.864v2.237a2 2 0 01-1.669-1.046L12 15.763V10.333z" />
          </svg>
        </div>
      )}
    </div>
  );
};
