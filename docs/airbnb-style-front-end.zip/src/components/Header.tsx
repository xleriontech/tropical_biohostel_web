import React from "react";

interface HeaderProps {
  onSearchClick: () => void;
  onToggleLocation: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSearchClick, onToggleLocation }) => {
  return (
    <header className="bg-white shadow-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-4">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-rose-400 to-rose-600">
            <svg
              className="h-5 w-5 text-white"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
            </svg>
          </div>
          <span className="text-lg font-medium text-slate-900">StayVista</span>
        </div>

        <nav className="hidden items-center gap-6 text-sm font-medium text-slate-600 lg:flex">
          <a href="#" className="text-slate-900">Explorar</a>
          <a href="#" className="text-slate-600 hover:text-slate-900">Viajeros</a>
          <a href="#" className="text-slate-600 hover:text-slate-900">Inspiración</a>
          <a href="#" className="text-slate-600 hover:text-slate-900">Somos una comunidad</a>
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={onToggleLocation}
            className="flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
          >
            <svg className="h-4 w-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span className="hidden sm:block">Ubicación</span>
          </button>

          <button
            onClick={onSearchClick}
            className="flex items-center gap-2 rounded-full border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50"
          >
            <svg className="h-4 w-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <span className="hidden sm:block">Buscar</span>
          </button>

          <div className="relative">
            <button className="flex h-8 w-8 flex-row-reverse items-center justify-center rounded-full bg-slate-100 p-0 text-sm font-medium text-slate-600">
              <span className="sr-only">Cuenta</span>
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
            </button>
            <div className="absolute right-0 top-full z-50 mt-2 hidden rounded-xl bg-white p-4 shadow-lg ring-1 ring-slate-200 lg:block">
              <div className="text-center">
                <p className="text-sm font-medium text-slate-900">Bienvenido</p>
                <p className="text-xs text-slate-500">Obtén más de StayVista</p>
                <div className="mt-4 flex flex-col gap-2">
                  <button className="w-full rounded-lg border border-slate-200 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
                    Iniciar sesión
                  </button>
                  <button className="w-full rounded-lg bg-rose-500 py-2 text-sm font-medium text-white hover:bg-rose-600">
                    Registrarse
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
