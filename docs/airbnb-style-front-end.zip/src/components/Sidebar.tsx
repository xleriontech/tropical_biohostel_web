import React from "react";
import { categories, priceRange } from "../data/mockData";

interface SidebarProps {
  activeCategory: string;
  activePriceRange: string;
  onCategoryChange: (category: string) => void;
  onPriceRangeChange: (range: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeCategory,
  activePriceRange,
  onCategoryChange,
  onPriceRangeChange,
}) => {
  return (
    <aside className="hidden w-64 flex-shrink-0 border-r border-slate-200 p-6 lg:block">
      <div className="sticky top-24 space-y-8">
        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Tipo de propiedad</h3>
          <div className="space-y-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onCategoryChange(cat.id)}
                className={`flex w-full items-center justify-between px-3 py-2 text-sm font-medium transition ${
                  activeCategory === cat.id
                    ? "bg-rose-50 text-rose-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                <span className="flex items-center gap-2">
                  <span>{cat.icon}</span>
                  <span>{cat.name}</span>
                </span>
                {activeCategory === cat.id && (
                  <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9 2a1 1 0 000 2h10a1 1 0 000-2H9z" />
                    <path fillRule="evenodd" d="M4 5a2 2 0 012-2 3 3 0 003 3h10a3 3 0 003-3 2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 101-.99 1 1 0 00-1 .99zM3 7a1 1 0 011-1h1a1 1 0 110 2H4a1 1 0 01-1-1zm0 0a1 1 0 011-1h1a1 1 0 110 2H4a1 1 0 01-1-1zm0 0a1 1 0 011-1h1a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                  </svg>
                )}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Rango de precio</h3>
          <div className="space-y-1">
            {priceRange.map((range) => (
              <button
                key={range.label}
                onClick={() => onPriceRangeChange(range.label)}
                className={`w-full px-3 py-2 text-sm font-medium transition ${
                  activePriceRange === range.label
                    ? "bg-rose-50 text-rose-600"
                    : "text-slate-600 hover:bg-slate-50"
                }`}
              >
                {range.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Filtros</h3>
          <button className="w-full flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
            <span className="flex items-center gap-2">
              <svg className="h-4 w-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
              Más filtros
            </span>
          </button>
        </div>
      </div>
    </aside>
  );
};
