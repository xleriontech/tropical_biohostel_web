import React, { useState, useMemo } from "react";
import { User, users } from "../data/mockData";
import { UserCard } from "./UserCard";

interface UsersFeedProps {
  onUserClick: (user: User) => void;
}

export const UsersFeed: React.FC<UsersFeedProps> = ({ onUserClick }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuperhostsOnly, setShowSuperhostsOnly] = useState(false);

  const filteredUsers = useMemo(() => {
    return users.filter((user) => {
      if (showSuperhostsOnly && !user.isSuperhost) return false;

      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesName = user.name.toLowerCase().includes(query);
        const matchesLocation = user.location.toLowerCase().includes(query);
        if (!matchesName && !matchesLocation) return false;
      }

      return true;
    });
  }, [searchQuery, showSuperhostsOnly]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-slate-900">Viajeros de confianza</h1>
        <p className="mt-2 text-slate-600">Conoce a los anfitrions más destacados de StayVista</p>
      </div>

      <div className="mb-6 flex flex-wrap gap-3">
        <div className="relative">
          <svg
            className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
            />
          </svg>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar anfitrión..."
            className="w-full max-w-xs rounded-lg border border-slate-300 bg-white pl-12 pr-4 py-3 text-sm focus:border-rose-500 focus:outline-none focus:ring-2 focus:ring-rose-200"
          />
        </div>

        <button
          onClick={() => setShowSuperhostsOnly(!showSuperhostsOnly)}
          className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-full transition ${
            showSuperhostsOnly
              ? "bg-rose-500 text-white"
              : "bg-slate-100 text-slate-700 hover:bg-slate-200"
          }`}
        >
          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
            <path d="M10 12a2 2 0 100-4 2 2 0 000 4zm0 0v-3m8 15H4v-2.5h16v2.5z" />
          </svg>
          Solo Superhosts
        </button>
      </div>

      {filteredUsers.length > 0 ? (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredUsers.map((user) => (
            <UserCard key={user.id} user={user} onUserClick={onUserClick} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="rounded-full bg-slate-100 p-4">
            <svg className="h-12 w-12 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
            </svg>
          </div>
          <h3 className="mt-4 text-lg font-medium text-slate-900">No se encontraron resultados</h3>
          <p className="mt-1 text-sm text-slate-500">Intenta cambiar los filtros de búsqueda.</p>
        </div>
      )}
    </div>
  );
};
