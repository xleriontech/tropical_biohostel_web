import React from "react";
import { User } from "../data/mockData";

interface UserProfileProps {
  user: User | null;
  onClose: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ user, onClose }) => {
  if (!user) return null;

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-24" onClick={handleBackdropClick}>
      <div className="pointer-events-none absolute inset-0 bg-black/40" />

      <div className="pointer-events-auto relative w-full max-w-xl mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm text-slate-600 transition hover:bg-white hover:text-slate-900"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Cover image */}
        <div className="relative h-32 bg-gradient-to-br from-rose-400 to-rose-600">
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
        </div>

        {/* Avatar */}
        <div className="relative mb-6">
          <div className="mx-auto flex -rotate-6">
            <div className="flex items-center justify-center overflow-hidden rounded-full bg-white ring-4 ring-white shadow-lg">
              <img
                src={user.avatar}
                alt={user.name}
                className="h-24 w-24 object-cover"
              />
            </div>
          </div>
          {user.isSuperhost && (
            <span className="absolute -right-2 top-6 flex h-6 w-6 items-center justify-center rounded-full bg-rose-500 text-xs font-bold text-white shadow-sm">
              S
            </span>
          )}
        </div>

        {/* Profile info */}
        <div className="px-6 pb-6">
          <div className="mb-2 flex items-start justify-between">
            <div>
              <h1 className="text-xl font-semibold text-slate-900">{user.name}</h1>
              <p className="text-sm text-slate-500">{user.location}</p>
              {user.isSuperhost && (
                <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-rose-50 px-3 py-1 text-xs font-medium text-rose-600">
                  <svg className="h-3.5 w-3.5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4zm0 0v-3m8 15H4v-2.5h16v2.5z" />
                  </svg>
                  Superhost
                </span>
              )}
            </div>
          </div>

          <p className="mb-6 text-sm text-slate-600">{user.about}</p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="rounded-xl bg-slate-50 p-4 text-center">
              <p className="text-2xl font-semibold text-slate-900">{user.stats.hosted}</p>
              <p className="text-xs text-slate-500">anfitriones</p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4 text-center">
              <p className="text-2xl font-semibold text-slate-900">{user.stats.guests}</p>
              <p className="text-xs text-slate-500">huéspedes</p>
            </div>
            <div className="rounded-xl bg-slate-50 p-4 text-center">
              <div className="flex items-center justify-center gap-1">
                <svg className="h-6 w-6 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <p className="text-2xl font-semibold text-slate-900">{user.responseRate}%</p>
              </div>
              <p className="text-xs text-slate-500">tasa respuesta</p>
            </div>
          </div>

          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2 text-slate-600">
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
              <span>Desde {user.joinedDate}</span>
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <span>{user.totalListings} propiedades</span>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-6 flex gap-3">
            <button className="flex-1 rounded-lg border border-slate-200 px-4 py-3 text-center text-sm font-medium text-slate-700 hover:bg-slate-50">
              Seguir
            </button>
            <button className="flex-1 rounded-lg bg-rose-500 px-4 py-3 text-center text-sm font-medium text-white hover:bg-rose-600 shadow-sm">
              Contactar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
