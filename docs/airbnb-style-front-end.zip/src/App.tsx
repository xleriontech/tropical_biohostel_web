import { useState } from "react";
import { Header } from "./components/Header";
import { SearchBar } from "./components/SearchBar";
import { Feed } from "./components/Feed";
import { UsersFeed } from "./components/UsersFeed";
import { PropertyDetails } from "./components/PropertyDetails";
import { UserProfile } from "./components/UserProfile";
import { Property, User, properties } from "./data/mockData";

type View = "feed" | "users" | "trending";

export default function App() {
  const [currentView, setCurrentView] = useState<View>("feed");
  const [showSearchBar, setShowSearchBar] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const handleSearch = (destination: string) => {
    console.log("Searching for:", destination);
  };

  const handlePropertyClick = (property: Property) => {
    setSelectedProperty(property);
  };

  const handleUserClick = (user: User) => {
    setSelectedUser(user);
  };

  const handleFavoriteToggle = (updatedProperty: Property) => {
    // The property is already updated with the new favorite state
    // Focus on closing or refreshing
    console.log("Favorite toggled:", updatedProperty);
  };

  const handleClosePropertyDetails = () => {
    setSelectedProperty(null);
  };

  const handleCloseUserProfile = () => {
    setSelectedUser(null);
  };

  const featuredProperties = properties.filter((p) => p.isFeatured);

  return (
    <div className="min-h-screen bg-white">
      <Header
        onSearchClick={() => setShowSearchBar(true)}
        onToggleLocation={() => {}}
      />

      {/* Navigation tabs */}
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-3 lg:px-8">
          <div className="flex gap-6">
            <button
              onClick={() => setCurrentView("feed")}
              className={`pb-2 text-sm font-medium transition ${
                currentView === "feed"
                  ? "border-b-2 border-rose-500 text-rose-600"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              Explorar
            </button>
            <button
              onClick={() => setCurrentView("users")}
              className={`pb-2 text-sm font-medium transition ${
                currentView === "users"
                  ? "border-b-2 border-rose-500 text-rose-600"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              Viajeros
            </button>
            <button
              onClick={() => setCurrentView("trending")}
              className={`pb-2 text-sm font-medium transition ${
                currentView === "trending"
                  ? "border-b-2 border-rose-500 text-rose-600"
                  : "text-slate-500 hover:text-slate-700"
              }`}
            >
              Tendencias
            </button>
          </div>
        </div>
      </nav>

      {/* Main content */}
      <main>
        {currentView === "feed" && (
          <Feed onPropertyClick={handlePropertyClick} />
        )}

        {currentView === "users" && (
          <UsersFeed onUserClick={handleUserClick} />
        )}

        {currentView === "trending" && (
          <div className="mx-auto max-w-7xl px-4 py-6 lg:px-8">
            <div className="mb-8">
              <h1 className="text-2xl font-semibold text-slate-900">Destinos trending</h1>
              <p className="mt-2 text-slate-600">Los lugares más populares este mes</p>
            </div>

            <div className="mb-8">
              <h2 className="mb-4 text-lg font-semibold text-slate-900">Propiedades destacadas</h2>
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                {featuredProperties.map((property) => (
                  <PropertyDetails
                    key={property.id}
                    property={property}
                    onClose={handleClosePropertyDetails}
                    onFavoriteToggle={handleFavoriteToggle}
                  />
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Search Bar Modal */}
      {showSearchBar && (
        <SearchBar
          onClose={() => setShowSearchBar(false)}
          onSearch={handleSearch}
        />
      )}

      {/* Property Details Modal */}
      {selectedProperty && (
        <PropertyDetails
          property={selectedProperty}
          onClose={handleClosePropertyDetails}
          onFavoriteToggle={handleFavoriteToggle}
        />
      )}

      {/* User Profile Modal */}
      {selectedUser && (
        <UserProfile user={selectedUser} onClose={handleCloseUserProfile} />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-slate-50">
        <div className="mx-auto max-w-7xl px-4 py-12 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-6 lg:flex-row">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-rose-400 to-rose-600">
                <svg className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z" />
                </svg>
              </div>
              <span className="text-lg font-medium text-slate-900">StayVista</span>
            </div>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-slate-500">
              <a href="#" className="hover:text-slate-700">Código de conducta</a>
              <a href="#" className="hover:text-slate-700">Privacidad</a>
              <a href="#" className="hover:text-slate-700">Términos</a>
              <a href="#" className="hover:text-slate-700">Centro de ayuda</a>
            </div>
            <p className="text-xs text-slate-400">© 2024 StayVista. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
