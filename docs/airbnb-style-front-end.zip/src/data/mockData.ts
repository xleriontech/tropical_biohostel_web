export interface Property {
  id: string;
  title: string;
  location: string;
  type: string;
  rating: number;
  reviews: number;
  price: number;
  originalPrice?: number;
  image: string;
  images: string[];
  host: {
    name: string;
    avatar: string;
    isSuperhost: boolean;
  };
  beds: number;
  baths: number;
  guests: number;
  amenities: string[];
  description: string;
  isFavorite: boolean;
  isFeatured?: boolean;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  isSuperhost: boolean;
  joinedDate: string;
  responseRate: number;
  totalListings: number;
  location: string;
  about: string;
  stats: {
    hosted: number;
    guests: number;
  };
}

export const properties: Property[] = [
  {
    id: "1",
    title: "Casa moderna con vistas al mar",
    location: "Barcelona, España",
    type: "Casa",
    rating: 4.92,
    reviews: 234,
    price: 185,
    originalPrice: 220,
    image: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800",
    images: [
      "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800",
    ],
    host: {
      name: "María García",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c2-30d87383b0f3?w=150",
      isSuperhost: true,
    },
    beds: 3,
    baths: 2,
    guests: 6,
    amenities: ["WiFi", "A/C", "Cocina", "Piscina", "Lavadora"],
    description: "Disfruta de una casa moderna con vistas espectaculares al mar. Perfecta para familias o grupos de amigos.",
    isFavorite: false,
    isFeatured: true,
  },
  {
    id: "2",
    title: "Apartamento estilo loft en el centro",
    location: "Madrid, España",
    type: "Apartamento",
    rating: 4.85,
    reviews: 156,
    price: 95,
    image: "https://images.unsplash.com/photo-1560448226-538d3d35a668?w=800",
    images: [
      "https://images.unsplash.com/photo-1560448226-538d3d35a668?w=800",
      "https://images.unsplash.com/photo-1560185007-5f0bb185810a?w=800",
    ],
    host: {
      name: "Carlos Mendoza",
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
      isSuperhost: false,
    },
    beds: 2,
    baths: 1,
    guests: 4,
    amenities: ["WiFi", "A/C", "Cocina equipada"],
    description: "Un loft increíble en el centro de Madrid con acabados de alta calidad.",
    isFavorite: false,
  },
  {
    id: "3",
    title: "Suite con jacuzzi en la montaña",
    location: "Sierra Nevada, Granada",
    type: "Cabaña",
    rating: 4.98,
    reviews: 89,
    price: 220,
    image: "https://images.unsplash.com/photo-1582752329711-9e6a4c6b5e8d?w=800",
    images: [
      "https://images.unsplash.com/photo-1582752329711-9e6a4c6b5e8d?w=800",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
    ],
    host: {
      name: "Elena Torres",
      avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
      isSuperhost: true,
    },
    beds: 2,
    baths: 1,
    guests: 4,
    amenities: ["WiFi", "Jacuzzi", "A/C", "Chimenea", "Vistas"],
    description: "Relájate en una suite de lujo con jacuzzi y vistas impresionantes a la montaña.",
    isFavorite: false,
    isFeatured: true,
  },
  {
    id: "4",
    title: "Penthouse de lujo con terraza",
    location: "Valencia, España",
    type: "Penthouse",
    rating: 4.95,
    reviews: 312,
    price: 280,
    originalPrice: 350,
    image: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800",
    images: [
      "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800",
      "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800",
      "https://images.unsplash.com/photo-1600573472592-401b143e08a3?w=800",
    ],
    host: {
      name: "David López",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
      isSuperhost: true,
    },
    beds: 4,
    baths: 3,
    guests: 8,
    amenities: ["WiFi", "A/C", "Terraza", "Cocina gourmet", "Lavadora", "Acuario"],
    description: "Un penthouse de lujo con terraza panorámica y vistas al mar. Experimenta el máximo confort.",
    isFavorite: false,
    isFeatured: true,
  },
  {
    id: "5",
    title: "Departamento amurallado histórico",
    location: "Toledo, España",
    type: "Departamento",
    rating: 4.78,
    reviews: 201,
    price: 110,
    image: "https://images.unsplash.com/photo-1560448226-538d3d35a668?w=800",
    images: [
      "https://images.unsplash.com/photo-1560448226-538d3d35a668?w=800",
      "https://images.unsplash.com/photo-1600566753181-3f8d6f15b3e6?w=800",
    ],
    host: {
      name: "Sofía Romero",
      avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
      isSuperhost: false,
    },
    beds: 3,
    baths: 2,
    guests: 5,
    amenities: ["WiFi", "A/C", "Cocina", "Balcón"],
    description: "Un encanto histórico en el centro de Toledo con todos los comodidades modernas.",
    isFavorite: false,
  },
  {
    id: "6",
    title: "Cabaña eco-constructiva en la selva",
    location: "La Gomera, Canarias",
    type: "Cabaña",
    rating: 4.99,
    reviews: 67,
    price: 145,
    image: "https://images.unsplash.com/photo-1582752329711-9e6a4c6b5e8d?w=800",
    images: [
      "https://images.unsplash.com/photo-1582752329711-9e6a4c6b5e8d?w=800",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800",
    ],
    host: {
      name: "Javier Martín",
      avatar: "https://images.unsplash.com/photo-1492562080162-7c5dd9d33846?w=150",
      isSuperhost: true,
    },
    beds: 2,
    baths: 1,
    guests: 4,
    amenities: ["WiFi", "Casa de campo", "Huerto", "Aire libre"],
    description: "Una experiencia única en una cabaña eco-constructiva rodeada de naturaleza.",
    isFavorite: false,
    isFeatured: true,
  },
];

export const users: User[] = [
  {
    id: "u1",
    name: "María García",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c2-30d87383b0f3?w=150",
    isSuperhost: true,
    joinedDate: "2019",
    responseRate: 98,
    totalListings: 5,
    location: "Barcelona, España",
    about: "Bienvenidos a mi espacio! Soy arquitecta y amo compartir mi hogar con viajeros de todo el mundo.",
    stats: {
      hosted: 156,
      guests: 342,
    },
  },
  {
    id: "u2",
    name: "Carlos Mendoza",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    isSuperhost: false,
    joinedDate: "2021",
    responseRate: 95,
    totalListings: 3,
    location: "Madrid, España",
    about: "Marketing Digital por día, anfitrión por la noche. Me encanta recibir a viajeros curiosos.",
    stats: {
      hosted: 89,
      guests: 178,
    },
  },
  {
    id: "u3",
    name: "Elena Torres",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150",
    isSuperhost: true,
    joinedDate: "2018",
    responseRate: 100,
    totalListings: 7,
    location: "Granada, España",
    about: "Desde hace 5 años comparto espacios especiales con personas de todas partes del mundo.",
    stats: {
      hosted: 234,
      guests: 412,
    },
  },
  {
    id: "u4",
    name: "David López",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
    isSuperhost: true,
    joinedDate: "2020",
    responseRate: 97,
    totalListings: 4,
    location: "Valencia, España",
    about: "Empresario y amante de la gastronomía. Mi penthouse es una joya en el corazón de Valencia.",
    stats: {
      hosted: 198,
      guests: 287,
    },
  },
  {
    id: "u5",
    name: "Sofía Romero",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
    isSuperhost: false,
    joinedDate: "2022",
    responseRate: 92,
    totalListings: 2,
    location: "Toledo, España",
    about: "Me encanta mostrar la belleza histórica de Toledo a visitantes de todo el mundo.",
    stats: {
      hosted: 45,
      guests: 92,
    },
  },
  {
    id: "u6",
    name: "Javier Martín",
    avatar: "https://images.unsplash.com/photo-1492562080162-7c5dd9d33846?w=150",
    isSuperhost: true,
    joinedDate: "2019",
    responseRate: 99,
    totalListings: 3,
    location: "La Gomera, Canarias",
    about: "Naturalista y biodiversity lover. Comparto mi cabaña para que descubras la magia de las Islas Canarias.",
    stats: {
      hosted: 167,
      guests: 234,
    },
  },
];

export const categories = [
  { id: "all", name: "Todo", icon: "🏠" },
  { id: "house", name: "Casas", icon: "🏡" },
  { id: "apartment", name: "Apartamentos", icon: "🏢" },
  { id: "cabin", name: "Cabañas", icon: "🛖" },
  { id: "penthouse", name: "Penthouses", icon: "✨" },
  { id: "unique", name: "Experiencias únicas", icon: "🎯" },
];

export const priceRange = [
  { min: 0, max: 100, label: "Económico" },
  { min: 100, max: 200, label: "Medio" },
  { min: 200, max: 500, label: "Lujo" },
];
